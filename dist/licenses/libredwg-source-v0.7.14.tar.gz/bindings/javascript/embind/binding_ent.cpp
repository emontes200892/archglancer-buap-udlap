#include <emscripten/bind.h>
#include <string>

#include "dwg.h"
#include "dwg_api.h"
#include "binding_common.h"


using namespace emscripten;

uintptr_t dwg_entity_owner_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  const void * ent = reinterpret_cast<const void *>(ent_ptr);
  return reinterpret_cast<uintptr_t>(dwg_entity_owner(ent));
}

emscripten::val dwg_entity_polyline_2d_get_numpoints_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  int error = 0;
  auto numpoints = dwg_object_polyline_2d_get_numpoints(obj, &error);

  emscripten::val result = emscripten::val::object();
  result.set("error", error);
  result.set("data", numpoints);
  return result;
}

emscripten::val dwg_entity_polyline_2d_get_points_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  int error = 0;
  auto numpoints = dwg_object_polyline_2d_get_numpoints(obj, &error);
  if (error != 0) {
    emscripten::val result = emscripten::val::object();
    result.set("success", false);
    result.set("message", std::string("Failed to get the number of points!"));
    result.set("data", numpoints);
    return result;
  }
  
  auto points = dwg_object_polyline_2d_get_points(obj, &error);
  if (error != 0) {
    emscripten::val result = emscripten::val::object();
    result.set("success", false);
    result.set("message", std::string("Failed to get points!"));
    emscripten::val points_obj = emscripten::val::array();
    for (int i = 0; i < numpoints; ++i) {
        points_obj.call<void>("push", point2d_to_js_object(&points[i]));
    }
    result.set("data", points_obj);
    return result;
  }

  emscripten::val result = emscripten::val::object();
  emscripten::val points_obj = emscripten::val::array();
  for (int index = 0; index < numpoints; ++index) {
    auto point = points[index];
    emscripten::val point_obj = point2d_to_js_object(&point);
    points_obj.call<void>("push", point_obj);
  }

  result.set("success", true);
  result.set("data", points_obj);
  free(points);
  return result;
}

emscripten::val vertex2d_to_js_object(Dwg_Entity_VERTEX_2D* vertex) {
  emscripten::val vertex_obj = emscripten::val::object();
  vertex_obj.set("flag", vertex->flag);
  vertex_obj.set("point", point3d_to_js_object(reinterpret_cast<dwg_point_3d*>(&(vertex->point))));
  vertex_obj.set("start_width", vertex->start_width);
  vertex_obj.set("end_width", vertex->end_width);
  vertex_obj.set("bulge", vertex->bulge);
  vertex_obj.set("tangent_dir", vertex->tangent_dir);
  return vertex_obj;
}

emscripten::val dwg_entity_polyline_2d_get_vertices_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  emscripten::val result = emscripten::val::object();

  int error = 0;
  if (obj && obj->fixedtype == DWG_TYPE_POLYLINE_2D) {
    BITCODE_BL i;
    Dwg_Data *dwg = obj->parent;
    Dwg_Entity_POLYLINE_2D *_obj = obj->tio.entity->tio.POLYLINE_2D;
    BITCODE_BL num_points
        = dwg_object_polyline_2d_get_numpoints (obj, &error);
    Dwg_Entity_VERTEX_2D *vertex = NULL;
    dwg_point_2d *ptx;

    if (!num_points || error) {
      result.set("success", false);
      result.set("message", std::string("Failed to get the number of vertices!"));
      return result;
    }

    emscripten::val vertices_obj = emscripten::val::array();
    if (dwg->header.version >= R_2004) {
      for (i = 0; i < num_points; i++) {
        Dwg_Object *vobj = dwg_ref_object (dwg, _obj->vertex[i]);
        if (vobj && vobj->fixedtype == DWG_TYPE_VERTEX_2D
            && (vertex = dwg_object_to_VERTEX_2D (vobj))) {
          emscripten::val vertex_obj = vertex2d_to_js_object(vertex);
          vertices_obj.call<void>("push", vertex_obj);
        } else {
          result.set("success", false);
          result.set("message", std::string("Not all of vertices returned!"));
        }
      }
      result.set("data", vertices_obj);
    }
    // iterate over first_vertex - last_vertex
    else if (dwg->header.version >= R_13b1) {
      Dwg_Object *vobj = dwg_ref_object (dwg, _obj->first_vertex);
      Dwg_Object *vlast = dwg_ref_object (dwg, _obj->last_vertex);
      if (!vobj) {
        result.set("success", false);
        result.set("message", std::string("Failed to get points!"));
      } else {
        i = 0;
        do {
          if (vobj->fixedtype == DWG_TYPE_VERTEX_2D
              && (vertex = dwg_object_to_VERTEX_2D (vobj))) {
            emscripten::val vertex_obj = vertex2d_to_js_object(vertex);
            vertices_obj.call<void>("push", vertex_obj);
            i++;
            if (i > num_points) {
              result.set("success", false);
              result.set("message", std::string("Index error! Exceed the number of vertices!"));
              break;
            }
          } else {
            result.set("success", false);
            result.set("message", std::string("Not all of vertices returned!"));
          }
        } while ((vobj = dwg_next_object (vobj)) && vobj != vlast);
        result.set("data", vertices_obj);
      }
    }
    else { // <r13: iterate over vertices until seqend
      Dwg_Object *vobj = (Dwg_Object *)obj;
      i = 0;
      while ((vobj = dwg_next_object (vobj))
              && vobj->fixedtype != DWG_TYPE_SEQEND) {
        if (vobj->fixedtype == DWG_TYPE_VERTEX_2D
            && (vertex = dwg_object_to_VERTEX_2D (vobj))) {
          emscripten::val vertex_obj = vertex2d_to_js_object(vertex);
          vertices_obj.call<void>("push", vertex_obj);
          i++;
          if (i > num_points) {
            result.set("success", false);
            result.set("message", std::string("Index error! Exceed the number of vertices!"));
            break;
          }
        } else {
          result.set("success", false);
          result.set("message", std::string("Not all of vertices returned!"));
        }
      }
      result.set("data", vertices_obj);
    }
  } else {
    result.set("success", false);
    result.set("message", "Null pointer passed or object isn't a 2d poyline!");
  }
  return result;
}

emscripten::val dwg_entity_block_header_get_preview_wrapper(Dwg_Object_Object_Ptr obj_ptr) {
  Dwg_Object_BLOCK_HEADER* block_header = reinterpret_cast<Dwg_Object_BLOCK_HEADER*>(obj_ptr);
  emscripten::val result = emscripten::val::object();
  if (block_header) {
    result.set("data", dwg_ptr_to_unsigned_char_array(block_header->preview, block_header->preview_size));
  } else {
    result.set("success", false);
    result.set("message", "Null pointer passed!");
  }
  return result;
}

emscripten::val dwg_entity_get_preview_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  emscripten::val result = emscripten::val::object();
  if (!obj || obj->supertype != DWG_SUPERTYPE_ENTITY) {
    result.set("success", false);
    result.set("message", "Null pointer or not an entity!");
    return result;
  }
  Dwg_Object_Entity* ent = obj->tio.entity;
  if (!ent || !ent->preview || ent->preview_size <= 0) {
    result.set("success", true);
    result.set("data", emscripten::val::null());
    return result;
  }
  result.set("success", true);
  result.set("size", ent->preview_size);
  result.set("data", dwg_ptr_to_unsigned_char_array((unsigned char*)ent->preview,
                                                    ent->preview_size));
  return result;
}

emscripten::val dwg_entity_proxy_entity_get_entity_data_wrapper(uintptr_t ent_tio_ptr) {
  Dwg_Entity_PROXY_ENTITY* proxy =
      reinterpret_cast<Dwg_Entity_PROXY_ENTITY*>(ent_tio_ptr);
  emscripten::val result = emscripten::val::object();
  if (!proxy) {
    result.set("success", false);
    result.set("message", "Null pointer passed!");
    return result;
  }
  size_t size = proxy->data_size;
  if (size == 0 && proxy->data_numbits > 0) {
    size = (proxy->data_numbits + 7) / 8;
  }
  result.set("success", true);
  result.set("size", static_cast<BITCODE_BL>(size));
  result.set("numbits", proxy->data_numbits);
  if (!proxy->data || size == 0) {
    result.set("data", emscripten::val::null());
    return result;
  }
  result.set("data", dwg_ptr_to_unsigned_char_array(proxy->data, size));
  return result;
}

/**
 * OLEFRAME/OLE2FRAME store binary payloads in BITCODE_TF with an explicit
 * data_size. The generic dynapi TF path truncates at the first NUL via
 * std::string, so expose sized copies for these entities.
 */
static emscripten::val dwg_entity_ole_get_data_common(BITCODE_TF data,
                                                     BITCODE_BL data_size) {
  emscripten::val result = emscripten::val::object();
  result.set("success", true);
  result.set("size", data_size);
  if (!data || data_size == 0) {
    result.set("data", emscripten::val::null());
    return result;
  }
  result.set("data", dwg_ptr_to_unsigned_char_array(data, data_size));
  return result;
}

emscripten::val dwg_entity_ole2frame_get_data_wrapper(uintptr_t ent_tio_ptr) {
  Dwg_Entity_OLE2FRAME* ole =
      reinterpret_cast<Dwg_Entity_OLE2FRAME*>(ent_tio_ptr);
  if (!ole) {
    emscripten::val result = emscripten::val::object();
    result.set("success", false);
    result.set("message", "Null pointer passed!");
    return result;
  }
  return dwg_entity_ole_get_data_common(ole->data, ole->data_size);
}

emscripten::val dwg_entity_oleframe_get_data_wrapper(uintptr_t ent_tio_ptr) {
  Dwg_Entity_OLEFRAME* ole =
      reinterpret_cast<Dwg_Entity_OLEFRAME*>(ent_tio_ptr);
  if (!ole) {
    emscripten::val result = emscripten::val::object();
    result.set("success", false);
    result.set("message", "Null pointer passed!");
    return result;
  }
  return dwg_entity_ole_get_data_common(ole->data, ole->data_size);
}

emscripten::val dwg_entity_polyline_3d_get_numpoints_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  int error = 0;
  auto numpoints = dwg_object_polyline_3d_get_numpoints(obj, &error);

  emscripten::val result = emscripten::val::object();
  result.set("error", error);
  result.set("data", numpoints);
  return result;
}

emscripten::val dwg_entity_polyline_3d_get_points_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  int error = 0;
  auto numpoints = dwg_object_polyline_3d_get_numpoints(obj, &error);
  if (error != 0) {
    emscripten::val result = emscripten::val::object();
    result.set("success", false);
    result.set("message", std::string("Failed to get the number of points!"));
    result.set("data", numpoints);
    return result;
  }
  
  auto points = dwg_object_polyline_3d_get_points(obj, &error);
  if (error != 0) {
    emscripten::val result = emscripten::val::object();
    result.set("success", false);
    result.set("message", std::string("Failed to get points!"));
    emscripten::val points_obj = emscripten::val::array();
    for (int i = 0; i < numpoints; ++i) {
        points_obj.call<void>("push", point3d_to_js_object(&points[i]));
    }
    result.set("data", points_obj);
    return result;
  }

  emscripten::val result = emscripten::val::object();
  emscripten::val points_obj = emscripten::val::array();
  for (int index = 0; index < numpoints; ++index) {
    auto point = points[index];
    emscripten::val point_obj = point3d_to_js_object(&point);
    points_obj.call<void>("push", point_obj);
  }

  result.set("success", true);
  result.set("data", points_obj);
  free(points);
  return result;
}

emscripten::val vertex3d_to_js_object(Dwg_Entity_VERTEX_3D* vertex) {
  emscripten::val vertex_obj = emscripten::val::object();
  vertex_obj.set("flag", vertex->flag);
  vertex_obj.set("point", point3d_to_js_object(reinterpret_cast<dwg_point_3d*>(&(vertex->point))));
  return vertex_obj;
}

emscripten::val dwg_entity_polyline_3d_get_vertices_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  emscripten::val result = emscripten::val::object();

  int error = 0;
  if (obj && obj->fixedtype == DWG_TYPE_POLYLINE_3D) {
    BITCODE_BL i;
    Dwg_Data *dwg = obj->parent;
    Dwg_Entity_POLYLINE_3D *_obj = obj->tio.entity->tio.POLYLINE_3D;
    BITCODE_BL num_points
        = dwg_object_polyline_3d_get_numpoints (obj, &error);
    Dwg_Entity_VERTEX_3D *vertex = NULL;
    dwg_point_3d *ptx;

    if (!num_points || error) {
      result.set("success", false);
      result.set("message", std::string("Failed to get the number of vertices!"));
      return result;
    }

    emscripten::val vertices_obj = emscripten::val::array();
    if (dwg->header.version >= R_2004) {
      for (i = 0; i < num_points; i++) {
        Dwg_Object *vobj = dwg_ref_object (dwg, _obj->vertex[i]);
        if (vobj && vobj->fixedtype == DWG_TYPE_VERTEX_3D
            && (vertex = dwg_object_to_VERTEX_3D (vobj))) {
          emscripten::val vertex_obj = vertex3d_to_js_object(vertex);
          vertices_obj.call<void>("push", vertex_obj);
        } else {
          result.set("success", false);
          result.set("message", std::string("Not all of vertices returned!"));
        }
      }
      result.set("data", vertices_obj);
    }
    // iterate over first_vertex - last_vertex
    else if (dwg->header.version >= R_13b1) {
      Dwg_Object *vobj = dwg_ref_object (dwg, _obj->first_vertex);
      Dwg_Object *vlast = dwg_ref_object (dwg, _obj->last_vertex);
      if (!vobj) {
        result.set("success", false);
        result.set("message", std::string("Failed to get points!"));
      } else {
        i = 0;
        do {
          if (vobj->fixedtype == DWG_TYPE_VERTEX_3D
              && (vertex = dwg_object_to_VERTEX_3D (vobj))) {
            emscripten::val vertex_obj = vertex3d_to_js_object(vertex);
            vertices_obj.call<void>("push", vertex_obj);
            i++;
            if (i > num_points) {
              result.set("success", false);
              result.set("message", std::string("Index error! Exceed the number of vertices!"));
              break;
            }
          } else {
            result.set("success", false);
            result.set("message", std::string("Not all of vertices returned!"));
          }
        } while ((vobj = dwg_next_object (vobj)) && vobj != vlast);
        result.set("data", vertices_obj);
      }
    }
    else { // <r13: iterate over vertices until seqend
      Dwg_Object *vobj = (Dwg_Object *)obj;
      i = 0;
      while ((vobj = dwg_next_object (vobj))
              && vobj->fixedtype != DWG_TYPE_SEQEND) {
        if (vobj->fixedtype == DWG_TYPE_VERTEX_3D
            && (vertex = dwg_object_to_VERTEX_3D (vobj))) {
          emscripten::val vertex_obj = vertex3d_to_js_object(vertex);
          vertices_obj.call<void>("push", vertex_obj);
          i++;
          if (i > num_points) {
            result.set("success", false);
            result.set("message", std::string("Index error! Exceed the number of vertices!"));
            break;
          }
        } else {
          result.set("success", false);
          result.set("message", std::string("Not all of vertices returned!"));
        }
      }
      result.set("data", vertices_obj);
    }
  } else {
    result.set("success", false);
    result.set("message", "Null pointer passed or object isn't a 3d poyline!");
  }
  return result;
}

emscripten::val dwg_entity_insert_get_attribs_wrapper(Dwg_Object_Entity_Ptr obj_ptr) {
  Dwg_Entity_INSERT* ent = reinterpret_cast<Dwg_Entity_INSERT*>(obj_ptr);
  emscripten::val result = emscripten::val::object();
  emscripten::val attribs = emscripten::val::array();
  result.set("data", attribs);

  if (!ent || !ent->has_attribs) {
    return result;
  }

  Dwg_Object *o;

  // R_2004a+ storage: owned handle vector. AC1018+ DWGs use this path.
  if (ent->num_owned > 0 && ent->attribs) {
    for (BITCODE_BL j = 0; j < ent->num_owned; j++) {
      o = ent->attribs[j] ? ent->attribs[j]->obj : NULL;
      if (o && o->fixedtype == DWG_TYPE_ATTRIB) {
        attribs.call<void>("push", reinterpret_cast<uintptr_t>(o));
      }
    }
    return result;
  }

  // R_13b1..R_2000 storage: linked list walk from first_attrib to last_attrib.
  // AC1015 (R_2000) DWGs never populate num_owned/attribs[] — the attribs are
  // reachable only as consecutive objects between first_attrib and last_attrib.
  if (ent->first_attrib && ent->first_attrib->obj) {
    Dwg_Object *first = ent->first_attrib->obj;
    Dwg_Object *last  = ent->last_attrib ? ent->last_attrib->obj : NULL;
    o = first;
    // Safety cap to avoid runaway loops on corrupt files.
    for (unsigned int guard = 0; o && guard < 100000; guard++) {
      if (o->fixedtype == DWG_TYPE_ATTRIB) {
        attribs.call<void>("push", reinterpret_cast<uintptr_t>(o));
      }
      if (o == last) break;
      o = dwg_next_object(o);
    }
  }

  return result;
}

EMSCRIPTEN_BINDINGS(libredwg_dwg_entity) {
  DEFINE_FUNC(dwg_entity_owner);
  DEFINE_FUNC(dwg_entity_polyline_2d_get_numpoints);
  DEFINE_FUNC(dwg_entity_polyline_2d_get_points);
  DEFINE_FUNC(dwg_entity_polyline_2d_get_vertices);
  DEFINE_FUNC(dwg_entity_polyline_3d_get_numpoints);
  DEFINE_FUNC(dwg_entity_polyline_3d_get_points);
  DEFINE_FUNC(dwg_entity_polyline_3d_get_vertices);
  DEFINE_FUNC(dwg_entity_block_header_get_preview);
  DEFINE_FUNC(dwg_entity_get_preview);
  DEFINE_FUNC(dwg_entity_proxy_entity_get_entity_data);
  DEFINE_FUNC(dwg_entity_ole2frame_get_data);
  DEFINE_FUNC(dwg_entity_oleframe_get_data);
  DEFINE_FUNC(dwg_entity_insert_get_attribs);
}

emscripten::val dwg_object_dictionary_get_texts_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  if (obj && obj->fixedtype == DWG_TYPE_DICTIONARY) {
    Dwg_Object_DICTIONARY* dict = obj->tio.object->tio.DICTIONARY;
    emscripten::val result = emscripten::val::object();
    result.set("success", true);
    result.set("data", dwg_ptr_to_wchar_string_array((BITCODE_TU*)dict->texts, dict->numitems));
    return result;
  } else {
    emscripten::val result = emscripten::val::object();
    result.set("success", false);
    result.set("message", std::string("Failed to get the number of points!"));
    result.set("data", emscripten::val::array());
    return result;
  }
}

EMSCRIPTEN_BINDINGS(libredwg_dwg_object) {
  DEFINE_FUNC(dwg_object_dictionary_get_texts);
}