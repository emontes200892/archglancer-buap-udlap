#include <stack>
#include <cstdio>
#include <cstdlib>
#include "binding_common.h"
#include "bits.h"

emscripten::val char_array_to_js_object(char* utf8) {
  emscripten::val str_obj = emscripten::val::object();
  const std::string str = std::string(utf8);
  str_obj.set("data", str);
  str_obj.set("bin", dwg_ptr_to_unsigned_char_array((unsigned char*)utf8, str.length()));
  return str_obj;
}

emscripten::val handle_to_js_object(Dwg_Handle* handle) {
  emscripten::val handle_obj = emscripten::val::object();
  handle_obj.set("code", handle->code);
  handle_obj.set("size", handle->size);
  handle_obj.set("value", handle->value);
  handle_obj.set("is_global", handle->is_global);
  return handle_obj;
}

emscripten::val object_ref_to_js_object(BITCODE_H object_ref) {
  emscripten::val handle_obj = emscripten::val::object();
  handle_obj.set("obj", reinterpret_cast<uintptr_t>(object_ref->obj));
  handle_obj.set("handleref", handle_to_js_object(&object_ref->handleref));
  handle_obj.set("absolute_ref", object_ref->absolute_ref);
  handle_obj.set("r11_idx", object_ref->r11_idx);
  return handle_obj;
}

emscripten::val color_to_js_object(const Dwg_Color* color) {
  emscripten::val color_obj = emscripten::val::object();
  color_obj.set("index", color->index);
  color_obj.set("flag", color->flag);
  color_obj.set("rgb", color->rgb);
  color_obj.set("method", static_cast<int>(color->method));
  color_obj.set("name", std::string(color->name));
  color_obj.set("book_name", std::string(color->book_name));
  color_obj.set("alpha_type", color->alpha_type);
  color_obj.set("alpha", color->alpha);
  return color_obj;
}

emscripten::val point2d_to_js_object(const dwg_point_2d* point) {
  emscripten::val point_obj = emscripten::val::object();
  point_obj.set("x", point->x);
  point_obj.set("y", point->y);
  return point_obj;
}

emscripten::val bitcode_2bd_to_js_object(const BITCODE_2BD* point) {
  emscripten::val point_obj = emscripten::val::object();
  point_obj.set("x", point->x);
  point_obj.set("y", point->y);
  return point_obj;
}

emscripten::val bitcode_2rd_to_js_object(const BITCODE_2RD* point) {
  emscripten::val point_obj = emscripten::val::object();
  point_obj.set("x", point->x);
  point_obj.set("y", point->y);
  return point_obj;
}

emscripten::val point3d_to_js_object(const dwg_point_3d* point) {
  emscripten::val point_obj = emscripten::val::object();
  point_obj.set("x", point->x);
  point_obj.set("y", point->y);
  point_obj.set("z", point->z);
  return point_obj;
}

emscripten::val bitcode_3bd_to_js_object(const BITCODE_3BD* point) {
  emscripten::val point_obj = emscripten::val::object();
  point_obj.set("x", point->x);
  point_obj.set("y", point->y);
  point_obj.set("z", point->z);
  return point_obj;
}

emscripten::val bitcode_3rd_to_js_object(const BITCODE_3RD* point) {
  emscripten::val point_obj = emscripten::val::object();
  point_obj.set("x", point->x);
  point_obj.set("y", point->y);
  point_obj.set("z", point->z);
  return point_obj;
}

emscripten::val point4d_to_js_object(const Dwg_SPLINE_control_point* point) {
  emscripten::val point_obj = emscripten::val::object();
  point_obj.set("x", point->x);
  point_obj.set("y", point->y);
  point_obj.set("z", point->z);
  point_obj.set("w", point->w);
  return point_obj;
}

/***********************************************************************/

/**
 * Return one JavaScript object for Dwg_Handle instance
 */
emscripten::val dwg_handle_wrapper(Dwg_Handle_Ptr handle_ptr) {
  Dwg_Handle* ptr = reinterpret_cast<Dwg_Handle*>(handle_ptr);
  return handle_to_js_object(ptr);
}

/**
 * Return one JavaScript object for Dwg_Object_Ref instance
 */
emscripten::val dwg_object_ref_wrapper(Dwg_Object_Ref_Ptr ref_ptr) {
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  return object_ref_to_js_object(ref);
}

EMSCRIPTEN_BINDINGS(libredwg_type) {
  DEFINE_FUNC(dwg_handle);
  DEFINE_FUNC(dwg_object_ref);
}

/***********************************************************************/

#define DEFINE_ARRAY_FUNC(type)                                                        \
emscripten::val dwg_ptr_to_##type##_array_wrapper(uintptr_t array_ptr, size_t size) {  \
  type* array = reinterpret_cast<type*>(array_ptr);                                    \
  emscripten::val jsArray = emscripten::val::array();                                  \
  for (int index = 0; index < size; ++index) {                                         \
    jsArray.call<void>("push", array[index]);                                          \
  }                                                                                    \
  return jsArray;                                                                      \
}

#define DEFINE_TYPED_ARRAY_FUNC(type)                                                  \
emscripten::val dwg_ptr_to_##type##_array_wrapper(uintptr_t array_ptr, size_t size) {  \
  type* array = reinterpret_cast<type*>(array_ptr);                                    \
  std::vector<type> data(array, array + size);                                         \
  return emscripten::val(emscripten::typed_memory_view(data.size(), data.data()));     \
}

DEFINE_ARRAY_FUNC(double)
DEFINE_ARRAY_FUNC(uint16_t)
DEFINE_ARRAY_FUNC(int16_t)
DEFINE_ARRAY_FUNC(uint32_t)
DEFINE_ARRAY_FUNC(int32_t)
DEFINE_ARRAY_FUNC(uint64_t)
DEFINE_ARRAY_FUNC(int64_t)

emscripten::val dwg_ptr_to_object_ref_array_wrapper(uintptr_t array_ptr, size_t size) {
  BITCODE_H* array = reinterpret_cast<BITCODE_H*>(array_ptr);
  emscripten::val jsArray = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    jsArray.call<void>("push", object_ref_to_js_object(array[index]));
  }
  return jsArray;
}

emscripten::val dwg_ptr_to_object_ref_ptr_array_wrapper(uintptr_t array_ptr, size_t size) {
  BITCODE_H* array = reinterpret_cast<BITCODE_H*>(array_ptr);
  emscripten::val jsArray = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    jsArray.call<void>("push", reinterpret_cast<uintptr_t>(array[index]));
  }
  return jsArray;
}

emscripten::val dwg_ptr_to_unsigned_char_array(unsigned char* array, size_t size) {
  if (array && size > 0) {
    emscripten::val memoryView
        = emscripten::val (emscripten::typed_memory_view (size, array));
    return memoryView.call<emscripten::val> ("slice");
  }
  return emscripten::val::null();
}

emscripten::val dwg_ptr_to_signed_char_array(signed char* array, size_t size) {
  if (array && size > 0) {
    emscripten::val memoryView
        = emscripten::val (emscripten::typed_memory_view (size, array));
    return memoryView.call<emscripten::val> ("slice");
  }
  return emscripten::val::null();
}

emscripten::val dwg_ptr_to_wchar_string_array(BITCODE_TU* array, size_t size) {
  emscripten::val jsArray = emscripten::val::array();
  for (size_t i = 0; i < size; ++i) {
    BITCODE_TU wstr = (BITCODE_TU)array[i];
    if (wstr) {
      char *utf8 = bit_convert_TU(wstr);
      if (wstr && !utf8) {
        jsArray.call<void>("push", emscripten::val::null());
      } else {
        jsArray.call<void>("push", std::string(utf8));
        free(utf8);
      }
    } else {
      jsArray.call<void>("push", emscripten::val::null());
    }
  }
  return jsArray;
}

emscripten::val dwg_ptr_to_wchar_string_array_wrapper(uintptr_t array_ptr, size_t size) {
  BITCODE_TU* array = reinterpret_cast<BITCODE_TU*>(array_ptr);
  return dwg_ptr_to_wchar_string_array(array, size);
}

emscripten::val dwg_ptr_to_unsigned_char_array_wrapper(uintptr_t array_ptr, size_t size) {
  unsigned char* array = reinterpret_cast<unsigned char*>(array_ptr);
  emscripten::val jsArray = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    jsArray.call<void>("push", array[index]);
  }
  return jsArray;
}

emscripten::val dwg_ptr_to_signed_char_array_wrapper(uintptr_t array_ptr, size_t size) {
  signed char* array = reinterpret_cast<signed char*>(array_ptr);
  emscripten::val jsArray = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    jsArray.call<void>("push", array[index]);
  }
  return jsArray;
}

emscripten::val dwg_ptr_to_point2d_array_wrapper(uintptr_t array_ptr, size_t size) {
  dwg_point_2d* array = reinterpret_cast<dwg_point_2d*>(array_ptr);

  emscripten::val points_obj = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    auto point = array[index];
    emscripten::val point_obj = point2d_to_js_object(&point);
    points_obj.call<void>("push", point_obj);
  }
  return points_obj;
}

emscripten::val dwg_ptr_to_point3d_array_wrapper(uintptr_t array_ptr, size_t size) {
  dwg_point_3d* array = reinterpret_cast<dwg_point_3d*>(array_ptr);

  emscripten::val points_obj = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    auto point = array[index];
    emscripten::val point_obj = point3d_to_js_object(&point);
    points_obj.call<void>("push", point_obj);
  }
  return points_obj;
}

emscripten::val dwg_ptr_to_point4d_array_wrapper(uintptr_t array_ptr, size_t size) {
  Dwg_SPLINE_control_point* array = reinterpret_cast<Dwg_SPLINE_control_point*>(array_ptr);

  emscripten::val points_obj = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    emscripten::val point_obj = emscripten::val::object();
    auto point = array[index];
    point_obj.set("x", point.x);
    point_obj.set("y", point.y);
    point_obj.set("z", point.z);
    point_obj.set("w", point.w);
    points_obj.call<void>("push", point_obj);
  }
  return points_obj;
}

static std::string ltype_dash_text_to_utf8(const Dwg_LTYPE_dash& dash) {
  if (!dash.text)
    return std::string();

  // R2007+ stores dash text as UCS-2LE inside strings_area. Treating it as a
  // C string stops at the first 0x00, which is the high byte of ASCII chars.
  bool is_tu = false;
  if (dash.parent) {
    int error = 0;
    Dwg_Data* dwg = dwg_obj_generic_dwg(dash.parent, &error);
    if (dwg)
      is_tu = IS_FROM_TU_DWG(dwg);
  }
  if (is_tu) {
    char* utf8 = bit_convert_TU((BITCODE_TU)dash.text);
    if (!utf8)
      return std::string();
    std::string out(utf8);
    free(utf8);
    return out;
  }
  return std::string(dash.text);
}

emscripten::val dwg_ptr_to_ltype_dash_array_wrapper(uintptr_t array_ptr, size_t size) {
  Dwg_LTYPE_dash* array = reinterpret_cast<Dwg_LTYPE_dash*>(array_ptr);

  emscripten::val dashes = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    emscripten::val dash_obj = emscripten::val::object();
    auto dash = array[index];
    dash_obj.set("length", dash.length);
    dash_obj.set("complex_shapecode", dash.complex_shapecode);
    dash_obj.set("style", reinterpret_cast<uintptr_t>(dash.style));
    dash_obj.set("x_offset", dash.x_offset);
    dash_obj.set("y_offset", dash.y_offset);
    dash_obj.set("scale", dash.scale);
    dash_obj.set("rotation", dash.rotation);
    dash_obj.set("shape_flag", dash.shape_flag);
    dash_obj.set("text", ltype_dash_text_to_utf8(dash));
    dashes.call<void>("push", dash_obj);
  }
  return dashes;
}

emscripten::val dwg_ptr_to_table_cell_array_wrapper(uintptr_t array_ptr, size_t size) {
  Dwg_TABLE_Cell* array = reinterpret_cast<Dwg_TABLE_Cell*>(array_ptr);

  emscripten::val cells = emscripten::val::array();
  for (int i = 0; i < size; ++i) {
    emscripten::val cell_obj = emscripten::val::object();
    auto cell = array[i];
    cell_obj.set("type", cell.type);
    cell_obj.set("flags", cell.flags);
    cell_obj.set("is_merged_value", cell.is_merged_value);
    cell_obj.set("is_autofit_flag", cell.is_autofit_flag);
    cell_obj.set("merged_width_flag", cell.merged_width_flag);
    cell_obj.set("merged_height_flag", cell.merged_height_flag);
    cell_obj.set("rotation", cell.rotation);
    cell_obj.set("text_value", std::string(cell.text_value));
    cell_obj.set("text_style", reinterpret_cast<uintptr_t>(cell.text_style));
    cell_obj.set("block_handle", object_ref_to_js_object(cell.block_handle));
    cell_obj.set("block_scale", cell.block_scale);
    cell_obj.set("additional_data_flag", cell.additional_data_flag);
    cell_obj.set("cell_flag_override", cell.cell_flag_override);
    cell_obj.set("virtual_edge_flag", cell.virtual_edge_flag);
    cell_obj.set("cell_alignment", cell.cell_alignment);
    cell_obj.set("bg_fill_none", cell.bg_fill_none);
    cell_obj.set("bg_color", color_to_js_object(&cell.bg_color));
    cell_obj.set("content_color", color_to_js_object(&cell.content_color));
    cell_obj.set("text_height", cell.text_height);
    cell_obj.set("top_grid_color", color_to_js_object(&cell.top_grid_color));
    cell_obj.set("top_grid_linewt", cell.top_grid_linewt);
    cell_obj.set("top_visibility", cell.top_visibility);
    cell_obj.set("right_grid_color", color_to_js_object(&cell.right_grid_color));
    cell_obj.set("right_grid_linewt", cell.right_grid_linewt);
    cell_obj.set("right_visibility", cell.right_visibility);
    cell_obj.set("bottom_grid_color", color_to_js_object(&cell.bottom_grid_color));
    cell_obj.set("bottom_grid_linewt", cell.bottom_grid_linewt);
    cell_obj.set("bottom_visibility", cell.bottom_visibility);
    cell_obj.set("left_grid_color", color_to_js_object(&cell.left_grid_color));
    cell_obj.set("left_grid_linewt", cell.left_grid_linewt);
    cell_obj.set("left_visibility", cell.left_visibility);
    cell_obj.set("num_attr_defs", cell.num_attr_defs);

    emscripten::val attr_defs_obj = emscripten::val::array();
    for (int j = 0; j < cell.num_attr_defs; ++j) {
      auto attr_def = cell.attr_defs[j];
      emscripten::val attr_def_obj = emscripten::val::object();
      attr_def_obj.set("attdef", object_ref_to_js_object(attr_def.attdef));
      attr_def_obj.set("text", std::string(attr_def.text));
      attr_def_obj.set("index", attr_def.index);
      attr_defs_obj.call<void>("push", attr_def_obj);
    }
    cell_obj.set("attr_defs", attr_defs_obj);
    
    cells.call<void>("push", cell_obj);
  }
  return cells;
}

emscripten::val dwg_ptr_to_hatch_defline_array_wrapper(uintptr_t array_ptr, size_t size) {
  Dwg_HATCH_DefLine* array = reinterpret_cast<Dwg_HATCH_DefLine*>(array_ptr);
  emscripten::val deflines = emscripten::val::array();
  for (int index = 0; index < size; ++index) {
    emscripten::val defline_obj = emscripten::val::object();
    auto defline = array[index];
    defline_obj.set("angle", defline.angle);
    defline_obj.set("pt0", point2d_to_js_object(reinterpret_cast<const dwg_point_2d*>(&defline.pt0)));
    defline_obj.set("offset", point2d_to_js_object(reinterpret_cast<const dwg_point_2d*>(&defline.offset)));
    defline_obj.set("dashes", dwg_ptr_to_double_array_wrapper(reinterpret_cast<uintptr_t>(defline.dashes), defline.num_dashes));
    deflines.call<void>("push", defline_obj);
  }
  return deflines;
}

emscripten::val dwg_ptr_to_hatch_path_array_wrapper(uintptr_t array_ptr, size_t size) {
  Dwg_HATCH_Path* array = reinterpret_cast<Dwg_HATCH_Path*>(array_ptr);
  emscripten::val pathes = emscripten::val::array();
  for (int i = 0; i < size; ++i) {
    emscripten::val path_obj = emscripten::val::object();
    auto path = array[i];
    // 2: is_polyline, 4: is_derived, 8: is_textbox,
    // 0x20: is_open, 0x80: is_textisland, 0x100: is_duplicate,
    // 0x200: is_annotative
    path_obj.set("flag", path.flag);
    auto num_segs_or_paths = path.num_segs_or_paths;
    path_obj.set("num_segs_or_paths", num_segs_or_paths);

    // Convert segment path
    if (path.segs) {
      emscripten::val segs = emscripten::val::array();
      for (int j = 0; j < num_segs_or_paths; ++j) {
        auto seg = path.segs[j];
        emscripten::val seg_obj = emscripten::val::object();

        // Edge type (only if boundary is not a polyline)
        // - 1: Line
        // - 2: Circular arc
        // - 3: Elliptic arc
        // - 4: Spline
        auto curve_type = seg.curve_type;
        seg_obj.set("curve_type", seg.curve_type);

        if (curve_type == 1) {
          // Line
          seg_obj.set("first_endpoint", bitcode_2rd_to_js_object(&seg.first_endpoint));
          seg_obj.set("second_endpoint", bitcode_2rd_to_js_object(&seg.second_endpoint));
        } else if (curve_type == 2) {
          // Circular arc
          seg_obj.set("center", bitcode_2rd_to_js_object(&seg.center));
          seg_obj.set("radius", seg.radius);
          seg_obj.set("start_angle", seg.start_angle);
          seg_obj.set("end_angle", seg.end_angle);
          seg_obj.set("is_ccw", seg.is_ccw);
        } else if (curve_type == 3) {
          // Elliptic arc
          seg_obj.set("center", bitcode_2rd_to_js_object(&seg.center));
          seg_obj.set("endpoint", bitcode_2rd_to_js_object(&seg.endpoint));
          seg_obj.set("minor_major_ratio", seg.minor_major_ratio);
          seg_obj.set("start_angle", seg.start_angle);
          seg_obj.set("end_angle", seg.end_angle);
          seg_obj.set("is_ccw", seg.is_ccw);
        } else if (curve_type == 4) {
          // Elliptic arc
          seg_obj.set("degree", seg.degree);
          seg_obj.set("is_rational", seg.is_rational);
          seg_obj.set("is_periodic", seg.is_periodic);

          // Convert knots
          auto num_knots = seg.num_knots;
          seg_obj.set("num_knots", num_knots);
          seg_obj.set("knots", dwg_ptr_to_double_array_wrapper(reinterpret_cast<uintptr_t>(seg.knots), num_knots));

          // Convert hatch control points
          auto num_control_points = seg.num_control_points;
          seg_obj.set("num_control_points", num_control_points);
          emscripten::val control_points = emscripten::val::array();
          for (int k = 0; k < num_control_points; ++k) {
            auto control_point = seg.control_points[k];
            emscripten::val control_point_obj = emscripten::val::object();
            control_point_obj.set("x", control_point.point.x);
            control_point_obj.set("y", control_point.point.y);
            control_point_obj.set("w", control_point.weight);
            control_points.call<void>("push", control_point_obj);
          }
          seg_obj.set("control_points", control_points);

          // Convert fit points
          auto num_fitpts = seg.num_fitpts;
          seg_obj.set("num_fitpts", num_fitpts);
          seg_obj.set("fitpts", dwg_ptr_to_point2d_array_wrapper(reinterpret_cast<uintptr_t>(seg.fitpts), num_fitpts));
          seg_obj.set("start_tangent", bitcode_2rd_to_js_object(&seg.start_tangent));
          seg_obj.set("end_tangent", bitcode_2rd_to_js_object(&seg.end_tangent));
        }

        segs.call<void>("push", seg_obj);
      }
      path_obj.set("segs", segs);
    }

    // Convert polyline path
    if (path.polyline_paths) {
      auto bulges_present = path.bulges_present;
      path_obj.set("bulges_present", bulges_present);
      path_obj.set("closed", path.closed);
      emscripten::val polyline_paths = emscripten::val::array();
      for (int j = 0; j < num_segs_or_paths; ++j) {
        auto polyline_path = path.polyline_paths[j];
        emscripten::val polyline_path_obj = emscripten::val::object();
        polyline_path_obj.set("point", bitcode_2rd_to_js_object(&polyline_path.point));
        if (bulges_present) {
          polyline_path_obj.set("bulge", polyline_path.bulge);
        }
        polyline_paths.call<void>("push", polyline_path_obj);
      }

      path_obj.set("polyline_paths", polyline_paths);
    }

    pathes.call<void>("push", path_obj);
  }
  return pathes;
}

emscripten::val dwg_ptr_to_hatch_gradient_color_array_wrapper(uintptr_t array_ptr, size_t size) {
  Dwg_HATCH_Color* array = reinterpret_cast<Dwg_HATCH_Color*>(array_ptr);
  emscripten::val colors = emscripten::val::array();
  for (int i = 0; i < size; ++i) {
    auto gradient_color = array[i];
    emscripten::val gradient_color_obj = emscripten::val::object();
    gradient_color_obj.set("reservedData", gradient_color.shift_value);
    gradient_color_obj.set("rgb", gradient_color.color.rgb);
    gradient_color_obj.set("colorIndex", gradient_color.color.index);
    colors.call<void>("push", gradient_color_obj);
  }
  return colors;
}

emscripten::val dwg_ptr_to_mline_vertex_array_wrapper(uintptr_t array_ptr, size_t size) {
  Dwg_MLINE_vertex* array = reinterpret_cast<Dwg_MLINE_vertex*>(array_ptr);
  emscripten::val vertices = emscripten::val::array();
  for (int i = 0; i < size; ++i) {
    emscripten::val vertex_obj = emscripten::val::object();
    auto vertex = array[i];

    vertex_obj.set("vertex", bitcode_3bd_to_js_object(&vertex.vertex));
    vertex_obj.set("vertex_direction", bitcode_3bd_to_js_object(&vertex.vertex_direction));
    vertex_obj.set("miter_direction", bitcode_3bd_to_js_object(&vertex.miter_direction));

    auto num_lines = vertex.num_lines;
    vertex_obj.set("num_lines", num_lines);
    
    // Convert lines
    if (vertex.lines) {
      emscripten::val lines = emscripten::val::array();
      for (int j = 0; j < num_lines; ++j) {
        auto line = vertex.lines[j];
        emscripten::val line_obj = emscripten::val::object();

        auto num_segparms = line.num_segparms;
        line_obj.set("num_segparms", num_segparms);
        emscripten::val segparms = emscripten::val::array();
        for (int k = 0; k < num_segparms; ++k) {
          segparms.call<void>("push", line.segparms[k]);
        }
        line_obj.set("segparms", segparms);

        auto num_areafillparms = line.num_areafillparms;
        line_obj.set("num_areafillparms", num_areafillparms);
        emscripten::val areafillparms = emscripten::val::array();
        for (int k = 0; k < num_areafillparms; ++k) {
          areafillparms.call<void>("push", line.areafillparms[k]);
        }
        line_obj.set("segparms", segparms);

        lines.call<void>("push", line_obj);
      }
      vertex_obj.set("lines", lines);
    }
    vertices.call<void>("push", vertex_obj);
  }
  return vertices;
}

EMSCRIPTEN_BINDINGS(libredwg_array) {
  DEFINE_FUNC(dwg_ptr_to_object_ref_array);
  DEFINE_FUNC(dwg_ptr_to_object_ref_ptr_array);
  DEFINE_FUNC(dwg_ptr_to_wchar_string_array);
  DEFINE_FUNC(dwg_ptr_to_unsigned_char_array);
  DEFINE_FUNC(dwg_ptr_to_signed_char_array);
  DEFINE_FUNC(dwg_ptr_to_uint16_t_array);
  DEFINE_FUNC(dwg_ptr_to_int16_t_array);
  DEFINE_FUNC(dwg_ptr_to_uint32_t_array);
  DEFINE_FUNC(dwg_ptr_to_int32_t_array);
  DEFINE_FUNC(dwg_ptr_to_uint64_t_array);
  DEFINE_FUNC(dwg_ptr_to_int64_t_array);
  DEFINE_FUNC(dwg_ptr_to_double_array);
  DEFINE_FUNC(dwg_ptr_to_point2d_array);
  DEFINE_FUNC(dwg_ptr_to_point3d_array);
  DEFINE_FUNC(dwg_ptr_to_point4d_array);
  DEFINE_FUNC(dwg_ptr_to_ltype_dash_array);
  DEFINE_FUNC(dwg_ptr_to_table_cell_array);
  DEFINE_FUNC(dwg_ptr_to_hatch_defline_array);
  DEFINE_FUNC(dwg_ptr_to_hatch_path_array);
  DEFINE_FUNC(dwg_ptr_to_hatch_gradient_color_array);
  DEFINE_FUNC(dwg_ptr_to_mline_vertex_array);
}

/***********************************************************************/

Dwg_Object_Object_Ptr dwg_object_get_tio_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  // The address of 'tio.entity' is same as the address of 'tio.object'.
  return (obj == NULL) ? 0 : reinterpret_cast<uintptr_t>(obj->tio.object);
}

int dwg_object_get_type_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return (obj == NULL) ? 0 : obj->type;
}

int dwg_object_get_fixedtype_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return (obj == NULL) ? 0 : static_cast<int>(obj->fixedtype);
}

int dwg_object_get_supertype_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return (obj == NULL) ? 0 : static_cast<int>(obj->supertype);
}

/**
 * public entity/object name
 */
emscripten::val dwg_object_get_name_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  if (obj) {
    return char_array_to_js_object(obj->name);
  }
  return emscripten::val::null();
}

/**
 * The internal dxf classname, often with a ACDB prefix
 */
std::string dwg_object_get_dxfname_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return (obj == NULL) ? 0 : std::string(obj->dxfname);
}

int dwg_object_get_handle_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return (obj == NULL) ? 0 : reinterpret_cast<uintptr_t>(&(obj->handle));
}

emscripten::val dwg_object_get_handle_object_wrapper(Dwg_Object_Ptr obj_ptr) {
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return handle_to_js_object(&(obj->handle));
}

/**
 * Methods to access fields of Dwg_Object
 */
EMSCRIPTEN_BINDINGS(libredwg_dwg_object) {
  DEFINE_FUNC(dwg_object_get_tio);
  DEFINE_FUNC(dwg_object_get_type);
  DEFINE_FUNC(dwg_object_get_supertype);
  DEFINE_FUNC(dwg_object_get_fixedtype);
  DEFINE_FUNC(dwg_object_get_name);
  DEFINE_FUNC(dwg_object_get_dxfname);
  DEFINE_FUNC(dwg_object_get_handle);
  DEFINE_FUNC(dwg_object_get_handle_object);
}

/***********************************************************************/

/** 
 * Convert dwg_object* from dwg_obj_obj*. 
*/
uintptr_t dwg_obj_obj_to_object_wrapper(uintptr_t obj_ptr) {
  dwg_obj_obj* obj = reinterpret_cast<dwg_obj_obj*>(obj_ptr);
  int error = 0;
  return reinterpret_cast<uintptr_t>(dwg_obj_obj_to_object(obj, &error));
}

/** 
 * Convert dwg_object* from any dwg_obj_*
*/
uintptr_t dwg_obj_generic_to_object_wrapper(uintptr_t obj_ptr) {
  void* obj = reinterpret_cast<void*>(obj_ptr);
  int error = 0;
  return reinterpret_cast<uintptr_t>(dwg_obj_generic_to_object(obj, &error));
}

/** 
 * Convert dwg_obj_obj* from dwg_object*. 
*/
uintptr_t dwg_object_to_object_wrapper(uintptr_t obj_ptr) {
  dwg_object* obj = reinterpret_cast<dwg_object*>(obj_ptr);
  int error = 0;
  return reinterpret_cast<uintptr_t>(dwg_object_to_object(obj, &error));
}

/** 
 * Get dwg_obj_obj->tio from dwg_object*. 
*/
uintptr_t dwg_object_to_object_tio_wrapper(uintptr_t obj_ptr) {
  if (!obj_ptr)
    return 0;
#if defined(__EMSCRIPTEN__)
  if (!wasm_ptr_in_bounds ((const void *)obj_ptr, sizeof (Dwg_Object)))
    return 0;
#endif
  dwg_object *obj = reinterpret_cast<dwg_object *>(obj_ptr);
  if (obj->supertype != DWG_SUPERTYPE_OBJECT)
    return 0;
  dwg_obj_obj *obj_obj = obj->tio.object;
  if (!obj_obj)
    return 0;
#if defined(__EMSCRIPTEN__)
  if (!wasm_ptr_in_bounds (obj_obj, sizeof (dwg_obj_obj)))
    return 0;
#endif
  // The address of the first item 'tio.APPID' in union is same as others.
  return reinterpret_cast<uintptr_t>(obj_obj->tio.APPID);
}

/** 
 * Convert dwg_obj_ent* from dwg object.
*/
uintptr_t dwg_object_to_entity_wrapper(uintptr_t obj_ptr) {
  dwg_object* obj = reinterpret_cast<dwg_object*>(obj_ptr);
  int error = 0;
  return reinterpret_cast<uintptr_t>(dwg_object_to_entity(obj, &error));
}

uintptr_t dwg_object_to_entity_tio_wrapper(uintptr_t obj_ptr) {
  if (!obj_ptr)
    return 0;
#if defined(__EMSCRIPTEN__)
  if (!wasm_ptr_in_bounds ((const void *)obj_ptr, sizeof (Dwg_Object)))
    return 0;
#endif
  dwg_object *obj = reinterpret_cast<dwg_object *>(obj_ptr);
  if (obj->supertype != DWG_SUPERTYPE_ENTITY)
    return 0;
  dwg_obj_ent *obj_ent = obj->tio.entity;
  if (!obj_ent)
    return 0;
#if defined(__EMSCRIPTEN__)
  if (!wasm_ptr_in_bounds (obj_ent, sizeof (dwg_obj_ent)))
    return 0;
#endif
  // The address of the first item 'tio.UNUSED' in union is same as others.
  return reinterpret_cast<uintptr_t>(obj_ent->tio.UNUSED);
}

/**
 * Methods to convert Dwg_Object instance
 */
EMSCRIPTEN_BINDINGS(libredwg_dwg_object_conversion) {
  DEFINE_FUNC(dwg_obj_obj_to_object);
  DEFINE_FUNC(dwg_obj_generic_to_object);
  DEFINE_FUNC(dwg_object_to_object);
  DEFINE_FUNC(dwg_object_to_object_tio);
  DEFINE_FUNC(dwg_object_to_entity);
  DEFINE_FUNC(dwg_object_to_entity_tio);
}

/***********************************************************************/

Dwg_Object_Object_Ptr dwg_object_object_get_tio_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return (obj_obj == NULL) ? 0 : reinterpret_cast<uintptr_t>(obj_obj->tio.APPID);
}

int dwg_object_object_get_objid_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return (obj_obj == NULL) ? 0 : obj_obj->objid;
}

uintptr_t dwg_object_object_get_ownerhandle_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return (obj_obj == NULL) ? 0 : reinterpret_cast<uintptr_t>(obj_obj->ownerhandle);
}

emscripten::val dwg_object_object_get_ownerhandle_object_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return object_ref_to_js_object(obj_obj->ownerhandle);
}

uintptr_t dwg_object_object_get_handle_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return (obj_obj == NULL) ? 0 : reinterpret_cast<uintptr_t>(obj_obj->handleref);
}

emscripten::val dwg_object_object_get_handle_object_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return handle_to_js_object(obj_obj->handleref);
}

int dwg_object_object_get_num_reactors_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return (obj_obj == NULL) ? 0 : obj_obj->num_reactors;
}

uintptr_t dwg_object_object_get_reactors_wrapper(Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj = reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  return (obj_obj == NULL) ? 0 : reinterpret_cast<uintptr_t>(obj_obj->reactors);
}

/**
 * Methods to access fields of Dwg_Object_Object
 */
EMSCRIPTEN_BINDINGS(libredwg_dwg_object_object) {
  DEFINE_FUNC(dwg_object_object_get_tio);
  DEFINE_FUNC(dwg_object_object_get_objid);
  DEFINE_FUNC(dwg_object_object_get_ownerhandle);
  DEFINE_FUNC(dwg_object_object_get_ownerhandle_object);
  DEFINE_FUNC(dwg_object_object_get_handle);
  DEFINE_FUNC(dwg_object_object_get_handle_object);
  DEFINE_FUNC(dwg_object_object_get_num_reactors);
  DEFINE_FUNC(dwg_object_object_get_reactors);
}

/***********************************************************************/

uintptr_t dwg_object_entity_get_ownerhandle_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return reinterpret_cast<uintptr_t>(dwg_ent_get_ownerhandle(ent, &error));
}

emscripten::val dwg_object_entity_get_ownerhandle_object_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  Dwg_Object_Ref* ownerhandle = dwg_ent_get_ownerhandle(ent, &error);
  return object_ref_to_js_object(ownerhandle);
}

uintptr_t dwg_object_entity_get_xdicobjhandle_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return reinterpret_cast<uintptr_t>(dwg_ent_get_xdicobjhandle(ent, &error));
}

emscripten::val dwg_object_entity_get_xdicobjhandle_object_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  Dwg_Object_Ref* xdicobjhandle = dwg_ent_get_xdicobjhandle(ent, &error);
  return object_ref_to_js_object(xdicobjhandle);
}

uintptr_t dwg_object_entity_get_handle_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  Dwg_Object* obj = dwg_ent_to_object(ent, &error);
  return reinterpret_cast<uintptr_t>(dwg_object_get_handle(obj, &error));
}

emscripten::val dwg_object_entity_get_handle_object_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  Dwg_Object* obj = dwg_ent_to_object(ent, &error);
  Dwg_Handle* handle = dwg_object_get_handle(obj, &error);
  return handle_to_js_object(handle);
}

emscripten::val dwg_object_entity_get_layer_object_ref_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  Dwg_Object_Ref* layer = dwg_ent_get_layer(ent, &error);
  return object_ref_to_js_object(layer);
}

emscripten::val dwg_object_entity_get_ltype_object_ref_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  Dwg_Object_Ref* layer = dwg_ent_get_ltype(ent, &error);
  return object_ref_to_js_object(layer);
}

emscripten::val dwg_object_entity_get_color_object_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  const Dwg_Color* color = dwg_ent_get_color(ent, &error);
  return color_to_js_object(color);
}

double dwg_object_entity_get_ltype_flags_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_linetype_flags(ent, &error);
}

/**
 * Get The line type scale factor of this entity.
 */
double dwg_object_entity_get_ltype_scale_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_linetype_scale(ent, &error);
}

/**
 * Get the line weight used by this entity.
 */
BITCODE_RC dwg_object_entity_get_line_weight_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_linewt(ent, &error);
}

/**
 * Get the entity mode of this entity
 * - 0: has no ownerhandle
 * - 1: paper space
 * - 2: model space
 * - 3: has ownerhandle
 */
BITCODE_BB dwg_object_entity_get_entmode_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_entmode(ent, &error);
}

/**
 * Get the invisibility state of this entity.
 */
BITCODE_BS dwg_object_entity_get_invisible_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_invisible(ent, &error);
}

BITCODE_BB dwg_object_entity_get_plotstyle_flags_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_plotstyle_flags(ent, &error);
}

BITCODE_BB dwg_object_entity_get_material_flags_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_material_flags(ent, &error);
}

BITCODE_BB dwg_object_entity_get_shadow_flags_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_shadow_flags(ent, &error);
}

BITCODE_BB dwg_object_entity_has_full_visualstyle_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_has_full_visualstyle(ent, &error);
}

BITCODE_BB dwg_object_entity_has_face_visualstyle_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_has_face_visualstyle(ent, &error);
}

BITCODE_BB dwg_object_entity_has_edge_visualstyle_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_has_edge_visualstyle(ent, &error);
}

BITCODE_BL dwg_object_entity_get_num_reactors_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return dwg_ent_get_num_reactors(ent, &error);
}

uintptr_t dwg_object_entity_get_reactors_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);
  int error = 0;
  return reinterpret_cast<uintptr_t>(dwg_ent_get_reactors(ent, &error));
}

emscripten::val dwg_object_entity_get_xdata_wrapper(Dwg_Object_Entity_Ptr ent_ptr) {
  Dwg_Object_Entity* ent = reinterpret_cast<Dwg_Object_Entity*>(ent_ptr);

  emscripten::val result = emscripten::val::array();
  for (int i = 0; i < ent->num_eed; i++) {
    Dwg_Eed *eed = &ent->eed[i];
    emscripten::val eed_obj = emscripten::val::object();

    // name of APPID
    Dwg_Object *appid = dwg_resolve_handle(ent->dwg, eed->handle.value);
    if (appid && appid->fixedtype == DWG_TYPE_APPID) {
      char *utf8 = bit_convert_TU((BITCODE_TU)appid->tio.object->tio.APPID->name);
      eed_obj.set("appName", std::string(utf8));
    } else {
      eed_obj.set("appName", std::string("ACAD"));
    }

    emscripten::val entries_obj = emscripten::val::array();
    std::stack<emscripten::val> stack;
    stack.push(entries_obj);
    for (int j = 0; j < eed->size; j++) {
      Dwg_Eed_Data *data = &eed->data[j];
      const int code = data->code + 1000;

      emscripten::val entry_obj = emscripten::val::object();
      entry_obj.set("code", code);
      switch (data->code) {
        case 0: {
          if (!data->u.eed_0.length)
            entry_obj.set("value", std::string(""));
          else if (data->u.eed_0.is_tu)
            entry_obj.set("value", std::string(bit_convert_TU(data->u.eed_0_r2007.string)));
          else
            entry_obj.set("value", std::string(data->u.eed_0.string));
          break;
        }
        case 2:
          if (data->u.eed_2.close) {
            if (!stack.empty()) {
              stack.pop();
            }
            if (stack.size() >= 1) {
              entries_obj = stack.top();
            }
          } else {
            entries_obj = emscripten::val::array();
            stack.push(entries_obj);
          }
          break;
        case 3:
          entry_obj.set("value", data->u.eed_3.layer);
          break;
        case 4:
          entry_obj.set("value", dwg_ptr_to_unsigned_char_array(data->u.eed_4.data, data->u.eed_4.length));
          break;
        case 5:
          entry_obj.set("value", data->u.eed_5.entity);
          break; // not in DXF
        case 10:
        case 11:
        case 12:
        case 13:
        case 14:
        case 15: {
          emscripten::val point_obj = emscripten::val::object();
          point_obj.set("x", data->u.eed_10.point.x);
          point_obj.set("y", data->u.eed_10.point.y);
          point_obj.set("z", data->u.eed_10.point.z);
          entry_obj.set("value", point_obj);
          break;
        }
        case 40:
        case 41:
        case 42:
          entry_obj.set("value", data->u.eed_40.real);
          break;
        case 70:
          entry_obj.set("value", data->u.eed_70.rs);
          break;
        case 71:
          entry_obj.set("value", data->u.eed_71.rl);
          break;
        default:
          entry_obj.set("value", 0);
      }
      entries_obj.call<void>("push", entry_obj);
    }

    eed_obj.set("value", entries_obj);
    result.call<void>("push", eed_obj);
  }
  return result;
}

/**
 * Methods to access fields of Dwg_Object_Entity
 */
EMSCRIPTEN_BINDINGS(libredwg_dwg_object_entity) {
  DEFINE_FUNC(dwg_object_entity_get_ownerhandle);
  DEFINE_FUNC(dwg_object_entity_get_ownerhandle_object);
  DEFINE_FUNC(dwg_object_entity_get_xdicobjhandle);
  DEFINE_FUNC(dwg_object_entity_get_xdicobjhandle_object);
  DEFINE_FUNC(dwg_object_entity_get_handle);
  DEFINE_FUNC(dwg_object_entity_get_handle_object);
  DEFINE_FUNC(dwg_object_entity_get_layer_object_ref);
  DEFINE_FUNC(dwg_object_entity_get_ltype_object_ref);
  DEFINE_FUNC(dwg_object_entity_get_color_object);
  DEFINE_FUNC(dwg_object_entity_get_ltype_flags);
  DEFINE_FUNC(dwg_object_entity_get_ltype_scale);
  DEFINE_FUNC(dwg_object_entity_get_line_weight);
  DEFINE_FUNC(dwg_object_entity_get_entmode);
  DEFINE_FUNC(dwg_object_entity_get_invisible);
  DEFINE_FUNC(dwg_object_entity_get_plotstyle_flags);
  DEFINE_FUNC(dwg_object_entity_get_material_flags);
  DEFINE_FUNC(dwg_object_entity_get_shadow_flags);
  DEFINE_FUNC(dwg_object_entity_has_full_visualstyle);
  DEFINE_FUNC(dwg_object_entity_has_face_visualstyle);
  DEFINE_FUNC(dwg_object_entity_has_edge_visualstyle);
  DEFINE_FUNC(dwg_object_entity_get_num_reactors);
  DEFINE_FUNC(dwg_object_entity_get_reactors);
  DEFINE_FUNC(dwg_object_entity_get_xdata);
}

/***********************************************************************/

/**
 * Returns the extension dictionary handle of a Dwg_Object_Object instance.
 */
emscripten::val dwg_object_object_get_xdicobjhandle_object_wrapper(
    Dwg_Object_Object_Ptr obj_obj_ptr) {
  Dwg_Object_Object* obj_obj =
      reinterpret_cast<Dwg_Object_Object*>(obj_obj_ptr);
  if (!obj_obj || !obj_obj->xdicobjhandle) {
    return emscripten::val::null();
  }
  return object_ref_to_js_object(obj_obj->xdicobjhandle);
}

/**
 * Walks an XRECORD Resbuf linked list and returns DXF group/value pairs.
 *
 * Values mirror the DXF XRECORD payload used by Layer Manager filters:
 * strings, numbers, booleans (0/1), uppercase hex handle strings, binary
 * byte arrays, and `{x,y,z}` for 3D points.
 */
emscripten::val dwg_object_xrecord_get_xdata_wrapper(uintptr_t xrecord_ptr) {
  emscripten::val result = emscripten::val::array();
  if (!xrecord_ptr) {
    return result;
  }
#if defined(__EMSCRIPTEN__)
  if (!wasm_ptr_in_bounds((const void*)xrecord_ptr,
                          sizeof(Dwg_Object_XRECORD))) {
    return result;
  }
#endif

  Dwg_Object_XRECORD* xrecord =
      reinterpret_cast<Dwg_Object_XRECORD*>(xrecord_ptr);
  Dwg_Resbuf* rbuf = xrecord->xdata;
  const BITCODE_BL limit =
      xrecord->num_xdata > 0 ? xrecord->num_xdata : 100000;
  BITCODE_BL count = 0;

  while (rbuf && count < limit) {
#if defined(__EMSCRIPTEN__)
    if (!wasm_ptr_in_bounds(rbuf, sizeof(Dwg_Resbuf))) {
      break;
    }
#endif
    const short dxftype = rbuf->type;
    const Dwg_Resbuf_Value_Type vtype =
        static_cast<Dwg_Resbuf_Value_Type>(dwg_resbuf_value_type(dxftype));

    emscripten::val entry = emscripten::val::object();
    entry.set("code", static_cast<int>(dxftype));

    switch (vtype) {
      case DWG_VT_STRING: {
        if (rbuf->value.str.is_tu) {
          char* utf8 = bit_convert_TU(rbuf->value.str.u.wdata);
          entry.set("value", utf8 ? std::string(utf8) : std::string(""));
          free(utf8);
        } else if (rbuf->value.str.u.data) {
          entry.set("value", std::string(rbuf->value.str.u.data));
        } else {
          entry.set("value", std::string(""));
        }
        break;
      }
      case DWG_VT_REAL:
        entry.set("value", rbuf->value.dbl);
        break;
      case DWG_VT_BOOL:
        entry.set("value", static_cast<int>(rbuf->value.i8) ? 1 : 0);
        break;
      case DWG_VT_INT8:
        entry.set("value", static_cast<int>(rbuf->value.i8));
        break;
      case DWG_VT_INT16:
        entry.set("value", static_cast<int>(rbuf->value.i16));
        break;
      case DWG_VT_INT32:
        entry.set("value", static_cast<int>(rbuf->value.i32));
        break;
      case DWG_VT_INT64:
        entry.set("value", static_cast<double>(rbuf->value.i64));
        break;
      case DWG_VT_POINT3D: {
        emscripten::val point = emscripten::val::object();
        point.set("x", rbuf->value.pt[0]);
        point.set("y", rbuf->value.pt[1]);
        point.set("z", rbuf->value.pt[2]);
        entry.set("value", point);
        break;
      }
      case DWG_VT_BINARY:
        entry.set(
            "value",
            dwg_ptr_to_unsigned_char_array(
                reinterpret_cast<unsigned char*>(rbuf->value.str.u.data),
                rbuf->value.str.size));
        break;
      case DWG_VT_HANDLE:
      case DWG_VT_OBJECTID: {
        char buf[32];
        std::snprintf(buf, sizeof(buf), "%llX",
                      static_cast<unsigned long long>(rbuf->value.absref));
        entry.set("value", std::string(buf));
        break;
      }
      case DWG_VT_INVALID:
      default:
        // Skip unknown / invalid codes so callers still get usable payload.
        rbuf = rbuf->nextrb;
        count++;
        continue;
    }

    result.call<void>("push", entry);
    rbuf = rbuf->nextrb;
    count++;
  }

  return result;
}

EMSCRIPTEN_BINDINGS(libredwg_dwg_object_xrecord) {
  DEFINE_FUNC(dwg_object_object_get_xdicobjhandle_object);
  DEFINE_FUNC(dwg_object_xrecord_get_xdata);
}

/***********************************************************************/

/**
 * Returns the absolute handle reference (field 'absolute_ref') of Dwg_Object_Ref*
 */
BITCODE_BL dwg_ref_get_absref_wrapper(Dwg_Object_Ref_Ptr ref_ptr) {
  if (!ref_ptr)
    return 0;
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  return ref->absolute_ref;
}

/**
 * Returns Dwg_Object* from Dwg_Object_Ref*
 */
Dwg_Object_Ptr dwg_ref_get_object_wrapper(Dwg_Object_Ref_Ptr ref_ptr) {
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  int error = 0;
  return reinterpret_cast<Dwg_Object_Ptr>(dwg_ref_get_object(ref, &error));
}

int dwg_ref_get_handle_wrapper(Dwg_Object_Ref_Ptr ref_ptr) {
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  return (ref == NULL) ? 0 : reinterpret_cast<uintptr_t>(&(ref->handleref));
}

emscripten::val dwg_ref_get_handle_object_wrapper(Dwg_Object_Ref_Ptr ref_ptr) {
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  return handle_to_js_object(&(ref->handleref));
}

EMSCRIPTEN_BINDINGS(libredwg_dwg_object_ref) {
  DEFINE_FUNC(dwg_ref_get_absref);
  DEFINE_FUNC(dwg_ref_get_object);
  DEFINE_FUNC(dwg_ref_get_handle);
  DEFINE_FUNC(dwg_ref_get_handle_object);
}

/***********************************************************************/

uintptr_t dwg_ref_object_wrapper(
  uintptr_t dwg_ptr,
  uintptr_t ref_ptr) {
  Dwg_Data* dwg = reinterpret_cast<Dwg_Data*>(dwg_ptr);
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  return reinterpret_cast<uintptr_t>(dwg_ref_object(dwg, ref));
}

uintptr_t dwg_ref_object_relative_wrapper(
  uintptr_t dwg_ptr,
  uintptr_t ref_ptr,
  uintptr_t obj_ptr) {
  Dwg_Data* dwg = reinterpret_cast<Dwg_Data*>(dwg_ptr);
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return reinterpret_cast<uintptr_t>(dwg_ref_object_relative(dwg, ref, obj));
}

uintptr_t dwg_ref_object_silent_wrapper(
  uintptr_t dwg_ptr,
  uintptr_t ref_ptr) {
  Dwg_Data* dwg = reinterpret_cast<Dwg_Data*>(dwg_ptr);
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  return reinterpret_cast<uintptr_t>(dwg_ref_object_silent(dwg, ref));
}

/** 
 * Resolve handle absref value to Dwg_Object*. 
*/
uintptr_t dwg_resolve_handle_wrapper(
  uintptr_t dwg_ptr,
  BITCODE_RLL absref) {
  Dwg_Data* dwg = reinterpret_cast<Dwg_Data*>(dwg_ptr);
  return reinterpret_cast<uintptr_t>(dwg_resolve_handle(dwg, absref));
}

/** 
 * Resolve handle to Dwg_Object* without warning info
*/
uintptr_t dwg_resolve_handle_silent_wrapper(
  uintptr_t dwg_ptr,
  const BITCODE_RLL absref) {
  Dwg_Data* dwg = reinterpret_cast<Dwg_Data*>(dwg_ptr);
  return reinterpret_cast<uintptr_t>(dwg_resolve_handle_silent(dwg, absref));
}

/** 
 * Resolve Dwg_Object_Ref* to Dwg_Object*. 
*/
int dwg_resolve_handleref_wrapper(
  uintptr_t ref_ptr,
  uintptr_t obj_ptr) {
  Dwg_Object_Ref* ref = reinterpret_cast<Dwg_Object_Ref*>(ref_ptr);
  Dwg_Object* obj = reinterpret_cast<Dwg_Object*>(obj_ptr);
  return dwg_resolve_handleref(ref, obj);
}

EMSCRIPTEN_BINDINGS(libredwg_conversion) {
  DEFINE_FUNC(dwg_ref_object);
  DEFINE_FUNC(dwg_ref_object_relative);
  DEFINE_FUNC(dwg_ref_object_silent);
  DEFINE_FUNC(dwg_resolve_handle);
  DEFINE_FUNC(dwg_resolve_handle_silent);
  DEFINE_FUNC(dwg_resolve_handleref);
}